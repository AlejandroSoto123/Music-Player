import vlc
import os

vlc_path = "/path/to/your/vlc/library"

os.environ["VLC_PLUGIN_PATH"] = vlc_path

songs = ["Feet Dont Fail Me Now.mp3", "We Are One.mp3", "Waka Waka.mp3", "Heat Waves.mp3", "Yo x mi, Tu x Mi.mp3"]

selected_song = None
while not selected_song:
    print("Please choose a song:")
    for i, song in enumerate(songs):
        print(f"{i+1}. {song}")
    choice = input("Enter the number corresponding to the song: ")
    if choice.isdigit() and 1 <= int(choice) <= len(songs):
        selected_song = songs[int(choice)-1]
    else:
        print("Invalid choice. Please try again.")

music = vlc.MediaPlayer(selected_song)

music.play()

while music.is_playing():
    pass

music.stop()
